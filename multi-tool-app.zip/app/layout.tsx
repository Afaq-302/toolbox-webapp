import type React from "react"
import type { Metadata } from "next"
import Link from "next/link"
import { Home } from "lucide-react"
import "./globals.css"

export const metadata: Metadata = {
  title: "ToolBox - Multi-Tool Utility App",
  description: "A collection of useful tools for everyday tasks",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-gray-50 flex flex-col">
        <nav className="bg-white shadow-sm border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <Link href="/" className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">TB</span>
                </div>
                <span className="text-xl font-bold text-gray-900">ToolBox</span>
              </Link>
              <Link
                href="/"
                className="flex items-center space-x-1 text-gray-600 hover:text-blue-600 transition-colors"
              >
                <Home className="w-4 h-4" />
                <span>Home</span>
              </Link>
            </div>
          </div>
        </nav>

        <main className="flex-1">{children}</main>

        <footer className="bg-white border-t mt-auto">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="text-center text-gray-600">
              <p>&copy; 2024 ToolBox. A collection of useful utilities for everyday tasks.</p>
              <p className="text-sm mt-1">Built with Next.js and Tailwind CSS</p>
            </div>
          </div>
        </footer>
      </body>
    </html>
  )
}
