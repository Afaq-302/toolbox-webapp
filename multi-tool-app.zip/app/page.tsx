import Link from "next/link"
import {
  Calculator,
  Type,
  Key,
  Palette,
  Timer,
  DollarSign,
  Activity,
  RotateCcw,
  Hash,
  Calendar,
  Ruler,
  Clock,
} from "lucide-react"

const tools = [
  {
    name: "Unit Converter",
    description: "Convert between different units of measurement",
    href: "/unit-converter",
    icon: Ruler,
    color: "bg-blue-500",
  },
  {
    name: "Age Calculator",
    description: "Calculate your exact age and next birthday",
    href: "/age-calculator",
    icon: Calendar,
    color: "bg-green-500",
  },
  {
    name: "Character Counter",
    description: "Count characters, words, and sentences",
    href: "/character-counter",
    icon: Hash,
    color: "bg-purple-500",
  },
  {
    name: "Password Generator",
    description: "Generate secure passwords with custom options",
    href: "/password-generator",
    icon: Key,
    color: "bg-red-500",
  },
  {
    name: "Text Case Converter",
    description: "Convert text between different cases",
    href: "/text-case-converter",
    icon: Type,
    color: "bg-yellow-500",
  },
  {
    name: "Currency Converter",
    description: "Convert between currencies with live rates",
    href: "/currency-converter",
    icon: DollarSign,
    color: "bg-emerald-500",
  },
  {
    name: "Pace Calculator",
    description: "Calculate running pace and speed",
    href: "/pace-calculator",
    icon: Activity,
    color: "bg-orange-500",
  },
  {
    name: "Color Converter",
    description: "Convert between HEX, RGB, and HSL colors",
    href: "/color-converter",
    icon: Palette,
    color: "bg-pink-500",
  },
  {
    name: "Stopwatch",
    description: "Precise timing with lap functionality",
    href: "/stopwatch",
    icon: Timer,
    color: "bg-indigo-500",
  },
  {
    name: "QR Code Generator",
    description: "Generate QR codes for text and URLs",
    href: "/qr-generator",
    icon: RotateCcw,
    color: "bg-teal-500",
  },
  {
    name: "Base64 Encoder",
    description: "Encode and decode Base64 strings",
    href: "/base64-converter",
    icon: Calculator,
    color: "bg-cyan-500",
  },
  {
    name: "World Clock",
    description: "View time in different time zones",
    href: "/world-clock",
    icon: Clock,
    color: "bg-violet-500",
  },
]

export default function HomePage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Welcome to ToolBox</h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          A comprehensive collection of useful tools for developers, students, writers, and everyday tasks. Choose a
          tool below to get started.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {tools.map((tool) => {
          const IconComponent = tool.icon
          return (
            <Link
              key={tool.href}
              href={tool.href}
              className="group bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md hover:border-gray-300 transition-all duration-200 hover:-translate-y-1"
            >
              <div className="flex flex-col items-center text-center space-y-4">
                <div
                  className={`w-12 h-12 ${tool.color} rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform duration-200`}
                >
                  <IconComponent className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{tool.name}</h3>
                  <p className="text-sm text-gray-600 leading-relaxed">{tool.description}</p>
                </div>
              </div>
            </Link>
          )
        })}
      </div>

      <div className="mt-16 text-center">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Why Choose ToolBox?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">🚀 Fast & Responsive</h3>
              <p className="text-gray-600 text-sm">Built with Next.js for optimal performance on all devices</p>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">🔒 Privacy First</h3>
              <p className="text-gray-600 text-sm">
                All calculations happen locally - your data never leaves your device
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">📱 Mobile Friendly</h3>
              <p className="text-gray-600 text-sm">Optimized for mobile use with touch-friendly interfaces</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
